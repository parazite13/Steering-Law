<?php
// Mot de passe de l'espace Admin
define('MDP_ADMIN', 'admin');

// Url absolue vers la racine de l'application
// Avec le "/" terminal
define('ABSURL', 'http://steering/');

// Adresse de l'hébergement MongoDb
define('DB_HOST', 'localhost');

// Nom de la base de données MongoDb
define('DB_NAME', 'steering');
?>