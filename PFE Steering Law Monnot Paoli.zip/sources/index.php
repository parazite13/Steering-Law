<?php
// Initialise l'application
require('init.php');
?>